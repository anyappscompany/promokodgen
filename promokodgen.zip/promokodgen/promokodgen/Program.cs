﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using Gif.Components;
using System.IO;
using System.Threading;
using System.Xml.Linq;
using System.Net;

namespace promokodgen
{
    class Program
    {

        static string url = "http://kuponello.ru/coupons.php";
        static string fiimg = "TemporaryFile_logo_plus_kluch.png";
        static string twiimg = "TemporaryFile_promokod_plus_link.png";
        /*
         * 5e2c878175900bcb6b24164764d2dd75
         * d2598a79668e8e95bca6b3f98d054825
         */
        static void Main(string[] args)
        {
            string line;
            List<string> kw = new List<string>();

            string img1 = "pat1.png"; // пустой фон
            string img2 = "pat2.png"; // верхний логотип
            string img3 = "pat3.png"; // рука
            string slog = "ДЕЙСТВУЮЩИЕ ПРОМОКОДЫ, СКИДКИ, АКЦИИ, БОНУСЫ, ВОЛШЕБНЫЕ СЛОВА, КОДОВЫЕ СЛОВА";
            string tmp_gif = "tmp.gif";
            

            /* чтение ключей */
            StreamReader fkwords = new StreamReader(@"kwords.txt");
            while ((line = fkwords.ReadLine()) != null)
            {
                kw.Add(line);
            }

            foreach (string slovo in kw)
            {
                Console.WriteLine(slovo);

                /* Создаю первый слайд: лого + ключевик */
                if (createTemporaryFile1(img1, img2, slovo))
                {
                    Console.WriteLine("Создан временный файл: 1-" + slovo + ".png");
                }
                else
                {
                    Console.WriteLine("Ошибка при создании временного файла: 1-" + slovo + ".png");
                    return;
                }

                /* Создаю второй слайд: "Действующие промокоды, акции...http://kuponello.ru/coupons" */
                if (createTemporaryFile2(img1, img3, slog, slovo))
                {
                    Console.WriteLine("Создан временный файл: 2-" + slovo + ".png");
                }
                else
                {
                    Console.WriteLine("Ошибка при создании временного файла: 2-" + slovo + ".png");
                    return;
                }
                Thread.Sleep(500);

                
                //Объеденяю 2 файла в gif
                //Конвертирую gif в flv

                string directory = AppDomain.CurrentDomain.BaseDirectory;

                String[] imageFilePaths = new String[] { directory + "tmpfiles\\1-" + slovo + ".png", directory + "tmpfiles\\2-" + slovo + ".png" };
                String outputFilePath = directory + tmp_gif;
                AnimatedGifEncoder e = new AnimatedGifEncoder();
                e.Start(outputFilePath);
                //e.SetDelay(500);
                //-1:no repeat,0:always repeat
                e.SetRepeat(0);
                //for (int i = 0, count = imageFilePaths.Length; i < count; i++)
                //{
                //    e.AddFrame(Image.FromFile(imageFilePaths[i]));
                //}
                e.SetDelay(2000);
                e.AddFrame(Image.FromFile(imageFilePaths[0]));
                e.SetDelay(2000);
                e.AddFrame(Image.FromFile(imageFilePaths[0]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));
                e.SetDelay(5000);
                e.AddFrame(Image.FromFile(imageFilePaths[1]));

                e.Finish();
               
                getvid(slovo);                

            }


         
            /* extract Gif */
            /*string outputPath = directory;
            GifDecoder gifDecoder = new GifDecoder();
            gifDecoder.Read(directory + tmp_gif);
            for (int i = 0, count = gifDecoder.GetFrameCount(); i < count; i++)
            {
                Image frame = gifDecoder.GetFrame(i); // frame i
                frame.Save(outputPath + Guid.NewGuid().ToString()
                                      + ".png", ImageFormat.Png);
            }*/
            
        }

        /* Создание первого кадра*/
        public static bool createTemporaryFile1(string img1, string img2, string kwslowo)
        {
            try
            {
                Size size = new Size(640, 480);
                Bitmap myBitmap1 = new Bitmap(img1);
                Bitmap myBitmap2 = new Bitmap(img2);
                Bitmap rezmyBitmap = new Bitmap(640, 480);
                rezmyBitmap = MakeImage1(size, myBitmap2, myBitmap1, 255, kwslowo);
                rezmyBitmap.Save(AppDomain.CurrentDomain.BaseDirectory + "tmpfiles\\1-" + kwslowo + ".png", ImageFormat.Png);
                rezmyBitmap.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при создании временного файла 1 " + ex.Message.ToString());
                Console.ReadKey();
                return false;
            }
            return true;
        }        
        public static Bitmap MakeImage1(Size ImgSize, Bitmap foreImg, Bitmap backImg, byte s, string slowo)
        {
            // ImgSize = размер картинки-результата, обе исходные картинки приводятся к указанному размеру
            // s прозрачность накладываемого изображения foreImg от 0 (100%) до 255 (0%)
            // результат наследует Альфа-канал фонового изображения
            // наложение использует Альфа-канал накладываемого изображения
            Bitmap resultImage = new Bitmap(Math.Max(backImg.Width, foreImg.Width), Math.Max(backImg.Height, foreImg.Height));
            Graphics g = Graphics.FromImage(resultImage);
            g.DrawImage(backImg, 0, 0);
            g.DrawImage(foreImg, 73, 40);

            StringFormat strFormat = new StringFormat();
            strFormat.Alignment = StringAlignment.Center;
           
            strFormat.LineAlignment = StringAlignment.Center;

            Font drawFont = new Font("Arial", 36, FontStyle.Bold);
            
            SolidBrush drawBrush = new SolidBrush(Color.Black);


            g.DrawString(FirstUpper(slowo), drawFont, drawBrush,
    new RectangleF(40, 235, 600, 245), strFormat);
            
            return resultImage;
        }
        public static string FirstUpper(string cap)
        {
            return cap.Substring(0, 1).ToUpper() + (cap.Length > 1 ? cap.Substring(1) : "");
        }
        /* Создание второго кадра */
        public static bool createTemporaryFile2(string img1, string img2, string slog, string kwslovo)
        {
            try
            {
                Size size = new Size(640, 480);
                Bitmap myBitmap1 = new Bitmap(img1);
                Bitmap myBitmap2 = new Bitmap(img2);
                Bitmap rezmyBitmap = new Bitmap(640, 480);
                rezmyBitmap = MakeImage2(size, myBitmap2, myBitmap1, 255, slog);
                rezmyBitmap.Save(AppDomain.CurrentDomain.BaseDirectory + "tmpfiles\\2-" + kwslovo + ".png", ImageFormat.Png);
                rezmyBitmap.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при создании временного файла 2 " + ex.Message.ToString());
                Console.ReadKey();
                return false;
            }
            return true;
        }
        public static Bitmap MakeImage2(Size ImgSize, Bitmap foreImg, Bitmap backImg, byte s, string slog)
        {
            
            // ImgSize = размер картинки-результата, обе исходные картинки приводятся к указанному размеру
            // s прозрачность накладываемого изображения foreImg от 0 (100%) до 255 (0%)
            // результат наследует Альфа-канал фонового изображения
            // наложение использует Альфа-канал накладываемого изображения
            Bitmap resultImage = new Bitmap(Math.Max(backImg.Width, foreImg.Width), Math.Max(backImg.Height, foreImg.Height));
            Graphics g = Graphics.FromImage(resultImage);
            g.DrawImage(backImg, 0, 0);
            g.DrawImage(foreImg, 533, 140);

            StringFormat strFormat = new StringFormat();
            strFormat.Alignment = StringAlignment.Center;

            strFormat.LineAlignment = StringAlignment.Center;

            Font drawFont = new Font("Arial", 30, FontStyle.Bold);

            SolidBrush drawBrush = new SolidBrush(Color.Black);


            g.DrawString(slog, drawFont, drawBrush,
    new RectangleF(20, 30, 600, 245), strFormat);

            Font drawFontUrl = new Font("Arial", 26, FontStyle.Bold);
            SolidBrush drawBrushUrl = new SolidBrush(Color.Blue);
            g.DrawString(url, drawFontUrl, drawBrushUrl,
    new RectangleF(20, 205, 600, 245), strFormat);

            Font drawFontBes = new Font("Arial", 36, FontStyle.Bold);
            SolidBrush drawBrushBes = new SolidBrush(Color.Red);
            g.DrawString("Бесплатно!", drawFontBes, drawBrushBes,
    new RectangleF(20, 285, 600, 245), strFormat);
            
            return resultImage;
        }

        private static string getServer()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://api.online-convert.com/get-queue");
            request.Method = "POST";
            request.ContentType = @"application/x-www-form-urlencoded";
            string inputdata = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" + @"<queue>
<apiKey>d2598a79668e8e95bca6b3f98d054825</apiKey>
<targetType>image</targetType>
</queue>";
            string postData = "queue=" + inputdata;
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(postData);
            request.ContentLength = byte1.Length;
            Stream newStream = request.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            newStream.Close();

            WebResponse response = request.GetResponse();
            Stream rs = response.GetResponseStream();
            StreamReader readStream = new StreamReader(rs, Encoding.UTF8);
            string result = readStream.ReadToEnd();
            response.Close();
            readStream.Close();
            XDocument xdoc = XDocument.Parse(result);
            string server = xdoc.Descendants("params").FirstOrDefault().Descendants("server").FirstOrDefault().Value;
            return server;
        }

        private static XDocument getStatus(string hash)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://api.online-convert.com/queue-status");
            request.Method = "POST";
            request.ContentType = @"application/x-www-form-urlencoded";
            string inputdatatemplate = "queue=<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" + @"<queue>
<apiKey>d2598a79668e8e95bca6b3f98d054825</apiKey>
<hash>{0}</hash>
</queue>";
            string postData = string.Format(inputdatatemplate, hash);
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(postData);
            request.ContentLength = byte1.Length;
            Stream newStream = request.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            newStream.Close();
            WebResponse response = request.GetResponse();
            Stream rs = response.GetResponseStream();
            StreamReader readStream = new StreamReader(rs, Encoding.UTF8);
            string result = readStream.ReadToEnd();
            response.Close();
            readStream.Close();
            XDocument xdoc = XDocument.Parse(result);
            return xdoc;
        }

        private static void download(string directdownload, string filename)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(directdownload);
            request.Method = "GET";
            WebResponse response = request.GetResponse();
            Stream rs = response.GetResponseStream();
            FileStream stream = new FileStream(filename, FileMode.Create);
            BinaryWriter writer = new BinaryWriter(stream);
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = rs.Read(buffer, 0, buffer.Length)) != 0)
            {
                writer.Write(buffer, 0, bytesRead);
            }
            rs.Close();
            writer.Close();
            stream.Close();
        }

        private static void getvid(string kw_slovo)
        {
            string s = getServer();
            string inputdata = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + @"<queue>
<apiKey>d2598a79668e8e95bca6b3f98d054825</apiKey> 
<targetType>image</targetType> 
<targetMethod>convert-to-flv</targetMethod> 
<testMode>true</testMode>
</queue>";

            string boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

            //C:\Users\Downloads\file.eps
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(s + "/queue-insert");
            request.ContentType = "multipart/form-data; boundary=" + boundary;
            request.Method = "POST";
            request.KeepAlive = true;
            request.Credentials =
            System.Net.CredentialCache.DefaultCredentials;

            Stream memStream = new System.IO.MemoryStream();
            byte[] boundarybytes = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");

            string formdataTemplate = "\r\n--" + boundary + "\r\nContent-Disposition: form-data; name=\"{0}\";\r\n\r\n{1}";

            //1 parameter that is not a file
            string formitem = string.Format(formdataTemplate, "queue", inputdata);
            byte[] formitembytes = System.Text.Encoding.UTF8.GetBytes(formitem);
            memStream.Write(formitembytes, 0, formitembytes.Length);

            memStream.Write(boundarybytes, 0, boundarybytes.Length);

            //1 file
            string headerTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\n Content-Type: application/octet-stream\r\n\r\n";

            string header = string.Format(headerTemplate, "file", @"tmp.gif");
            byte[] headerbytes = System.Text.Encoding.UTF8.GetBytes(header);
            memStream.Write(headerbytes, 0, headerbytes.Length);
            FileStream fileStream = new FileStream(@"tmp.gif", FileMode.Open, FileAccess.Read);
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
            {
                memStream.Write(buffer, 0, bytesRead);
            }
            memStream.Write(boundarybytes, 0, boundarybytes.Length);
            fileStream.Close();

            request.ContentLength = memStream.Length;
            Stream newStream = request.GetRequestStream();
            memStream.Position = 0;
            byte[] tempBuffer = new byte[memStream.Length];
            memStream.Read(tempBuffer, 0, tempBuffer.Length);
            memStream.Close();
            newStream.Write(tempBuffer, 0, tempBuffer.Length);
            newStream.Close();

            string statuscode;
            do
            {
                WebResponse response = request.GetResponse();
                Stream rs = response.GetResponseStream();
                StreamReader readStream = new StreamReader(rs, Encoding.UTF8);
                string result = readStream.ReadToEnd();
                response.Close();
                readStream.Close();
                //MessageBox.Show(result);
                Console.WriteLine("1 " + result);
                System.IO.File.WriteAllText(@"result.txt", result);
                XDocument xdoc = XDocument.Parse(result);
                string downloadUrl = xdoc.Descendants("params").FirstOrDefault().Descendants("downloadUrl").FirstOrDefault().Value;
                string hash = xdoc.Descendants("params").FirstOrDefault().Descendants("hash").FirstOrDefault().Value;
            label1:
                xdoc = getStatus(hash);
                statuscode = xdoc.Descendants("status").FirstOrDefault().Descendants("code").FirstOrDefault().Value;
                Console.WriteLine("++++++" + statuscode + "+++++");
                if (statuscode == "101" || statuscode == "104")
                {
                    //Trace.WriteLine("sleeping for 10s");
                    Console.WriteLine("2 " + "sleeping for 10s");
                    Thread.Sleep(1000 * 1);
                    goto label1;
                }
                else
                {
                    //Trace.WriteLine(xdoc);
                label2:
                    try
                    {
                        Console.WriteLine("3 " + xdoc);
                        string directDownload = xdoc.Descendants("params").FirstOrDefault().Descendants("directDownload").FirstOrDefault().Value; Console.WriteLine("--" + directDownload);
                        download(directDownload, AppDomain.CurrentDomain.BaseDirectory + "video/" + FirstUpper(kw_slovo) + ".flv");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        Thread.Sleep(30000);
                        goto label2;
                    }
                } 
            }
            while (statuscode == "101" || statuscode == "104");
            
        }
    }
}
